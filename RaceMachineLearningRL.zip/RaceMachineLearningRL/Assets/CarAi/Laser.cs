﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser : MonoBehaviour
{
    public Color laserColor = new Color(0, 1, 0, 0.5f);
    public int distanceLaser =50;
    public float finalLenght= 0.02f;
    public float initialLenght = 0.02f;

    private Vector3 positionLaser;
    private LineRenderer lineRenderer;
    private float distance = 0;
    // Start is called before the first frame update
    void Start()
    {
        distance = distanceLaser;
        positionLaser = new Vector3(0, 0, finalLenght);
        lineRenderer = gameObject.AddComponent<LineRenderer>();
        lineRenderer.material = new Material(Shader.Find("Particles/Standard Unlit"));
        lineRenderer.startColor = laserColor;
        lineRenderer.endColor = laserColor;
        lineRenderer.startWidth = initialLenght;
        lineRenderer.endWidth = finalLenght;
        lineRenderer.positionCount = 2;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 finalPoint = transform.position + transform.forward * distanceLaser;
        RaycastHit collisionPoint;
        if(Physics.Raycast(transform.position,transform.forward,out collisionPoint, distanceLaser))
        {
            lineRenderer.SetPosition(0, transform.position);
            lineRenderer.SetPosition(1, collisionPoint.point);
            distance = collisionPoint.distance;
            
        }
        else
        {
            lineRenderer.SetPosition(0, transform.position);
            lineRenderer.SetPosition(1, finalPoint);
            distance = distanceLaser;
        }
    }
    public float getDistance()
    {
        return distance/distanceLaser; // 0 and 1
    }
}
