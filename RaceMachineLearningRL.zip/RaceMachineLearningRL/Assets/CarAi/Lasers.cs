﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lasers : MonoBehaviour
{
    public Color colorBeam = new Color(0, 255, 0, 0.5f);//color of the laser - init
    public int distanceLaser = 20; // max distance of the laser
    public static int lasers = 5; //amount of laser
    public static int view = 120; // view angle of each laser
    private GameObject[] lasersObjects; // all lasor objects -> component linerenderer
    GameObject obj1;
    public float height = 0; // laser obj height in the object
    private int count;
    // Start is called before the first frame update
    void Start()
    {
        count = view / (lasers - 1);
        lasersObjects = new GameObject[lasers];

        for(int i = 0; i < lasers; i++)
        {
            float currentDegree = count * i - view / 2; // current degree of each object
            GameObject obj = new GameObject();
            Laser laser=obj.AddComponent<Laser>();
            laser.finalLenght = 0.02f;
            laser.laserColor = colorBeam;
            laser.distanceLaser = distanceLaser;
            laser.transform.position = new Vector3(transform.position.x, transform.position.y+height, transform.position.z);

            lasersObjects[i] = obj;
            lasersObjects[i].transform.Rotate(new Vector3(0,currentDegree,0));
            obj.transform.SetParent(transform);
        }
    }
    public float[] getDistance()
    {
        float[] lasers = new float[lasersObjects.Length];
        for(int i = 0; i < lasersObjects.Length; i++)
        {
            lasers[i] = lasersObjects[i].GetComponent<Laser>().getDistance();
        }
        return lasers;
    }
    // Update is called once per frame
    void Update()
    {
      
        foreach(GameObject obj in lasersObjects)
        {
            obj.transform.position = new Vector3(transform.position.x, transform.position.y + height, transform.position.z);
        
        }
        
    }

  
}

