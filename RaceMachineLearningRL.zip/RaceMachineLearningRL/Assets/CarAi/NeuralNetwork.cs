﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NeuralNetwork
{
    //LITTLE EXPLINATION
    /*
     In order to make a Neural Network we need inputs,
     then we need to process these inputs inside a hidden layer,
     and only after that generating our outputs
    */
    /************************************************************************/
    /************************************************************************/
    //PROGRAMMING IDEA
    /*
     Firts we initialize the weights as random numbers, then we will use genetics algorithim 
     to recieve the cross value of the best 'parents' and apply these values to the other generation
    */
    /************************************************************************/
    /************************************************************************/

    public int hiddenLayers = 1; // number of hidden layers
    public int sizeHiddenLayers = 10; //amount of neurons in the hidden layer
    public int outputs = 2; // outputs values
    public int inputs = 5; //input values
    public float maxInitialValue = 5f;

    private const float EULER_NUMBER = 2.71828f;
    private List<List<float>> neurons;
    private List<float[][]> weights;

    private int totalLayers = 0;

    public NeuralNetwork()
    {
        totalLayers = hiddenLayers + 2; // all layers
        //Initialize weights and neurons
        weights = new List<float[][]>();
        neurons = new List<List<float>>();

        //fill the neurons and weights
        for(int i=0; i < totalLayers; i++)
        {
            float[][] layerWeights;
            List<float> layer = new List<float>();
            int sizeLayer = getSizeLayer(i);
            if(i!= 1 + hiddenLayers)
            {
                layerWeights = new float[sizeLayer][];
                int nextSizeLayer = getSizeLayer(i + 1);
                for(int j = 0; j < sizeLayer; j++)//current
                {
                    layerWeights[j] = new float[nextSizeLayer];
                    for(int k = 0; k < nextSizeLayer; k++)//next
                    {
                        layerWeights[j][k] = getRandomValue();
                    }
                }
                weights.Add(layerWeights);
            }
            for(int j = 0; j < sizeLayer; j++)
            {
                layer.Add(0);
            }
            neurons.Add(layer);
        }

    }
    public NeuralNetwork(DNA dna)
    {
        List<float[][]> weightsDNA = dna.getDNA();
        totalLayers = hiddenLayers + 2; // all layers
        //Initialize weights and neurons
        weights = new List<float[][]>();
        neurons = new List<List<float>>();

        //fill the neurons and weights
        for (int i = 0; i < totalLayers; i++)
        {
            float[][] layerWeights;
            float[][] weightsDNALayer;
            List<float> layer = new List<float>();
            int sizeLayer = getSizeLayer(i);
            if (i != 1 + hiddenLayers)
            {
                weightsDNALayer = weightsDNA[i];
                layerWeights = new float[sizeLayer][];
                int nextSizeLayer = getSizeLayer(i + 1);
                for (int j = 0; j < sizeLayer; j++)//current
                {
                    layerWeights[j] = new float[nextSizeLayer];
                    for (int k = 0; k < nextSizeLayer; k++)//next
                    {
                        layerWeights[j][k] = weightsDNALayer[j][k];
                    }
                }
                weights.Add(layerWeights);
            }
            for (int j = 0; j < sizeLayer; j++)
            {
                layer.Add(0);
            }
            neurons.Add(layer);
        }

    }
    public void feedFoward(float[]inputs)
    {
        //Set inputs in input layer
        List<float> inputLayer = neurons[0];
        for(int i = 0; i < inputs.Length; i++)
        {
            inputLayer[i] = inputs[i];
        }
        //Update the neurons from input layer to the output layer
        for(int layer =0;layer<neurons.Count-1; layer++)
        {
            float[][] weightsLayer = weights[layer];
            int nextLayer = layer + 1;
            List<float> neuronsLayer = neurons[layer];
            List<float> neuronsNextLayer = neurons[nextLayer];
            for(int i = 0; i < neuronsNextLayer.Count; i++)//next layer
            {
                float sum = 0;
                for(int j = 0; j < neuronsLayer.Count; j++)
                {
                    sum += weightsLayer[j][i] * neuronsLayer[j];//Feed-foward multiplication
                }
                neuronsNextLayer[i] = sigmoid(sum);

            }
        }
        
    }
    public int getSizeLayer(int i)
    {
        //Layer position i
        int sizeLayer = 0;
        //Depending on the layer it will give a diff size
        if(i == 0)
        {
            sizeLayer = inputs;
        }
        else if(i == hiddenLayers + 1)
        {
            sizeLayer = outputs;
        }
        else
        {
            sizeLayer = sizeHiddenLayers;
        }
        return sizeLayer;
    }
    public List<float> getOutputs()
    {
        return neurons[neurons.Count - 1];
    }
    public float sigmoid(float x)
    {
        return 1 / (float)(1 + Mathf.Pow(EULER_NUMBER,-x));
    }
    public float getRandomValue()
    {
        return Random.Range(-maxInitialValue, maxInitialValue);
    }
    public List<List<float>> getNeurons()
    {
        return neurons;
    }
    public List<float[][]> getWeights()
    {
        return weights;
    }
}
