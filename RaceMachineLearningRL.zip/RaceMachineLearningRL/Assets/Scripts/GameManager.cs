﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    // Start is called before the first frame update
    public Camera mainCamera, secondCamera,smartCam;
    private int cameraChanger;
    void Start()
    {
        cameraChanger = 1;
        mainCamera.enabled = true;
        secondCamera.enabled = false;
        smartCam.enabled = false;

    }

    // Update is called once per frame
    void Update()
    {
        ChangeCamera();
        HandleChanging();
    }

    private void ChangeCamera()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            if (cameraChanger != 3)
                cameraChanger += 1;
            else
                cameraChanger = 1;
        }
    }
    private void HandleChanging()
    {
        if(cameraChanger == 1)
        {
            mainCamera.enabled = true;
            secondCamera.enabled = false;
            smartCam.enabled = false;

        }
        else if(cameraChanger==2)
        {
            mainCamera.enabled = false;
            secondCamera.enabled = true;
            smartCam.enabled = false;

        }
        else
        {
            mainCamera.enabled = false;
            secondCamera.enabled = false;
            smartCam.enabled = true;
        }
    }
}
